#!/data/data/com.termux/files/usr/bin/bash
# name: SSL Info
# desc: Zobrazí info o SSL certifikátu serveru (platnost, CA...)

if ! command -v openssl >/dev/null 2>&1; then
  echo "Tento plugin vyžaduje openssl. Nainstaluj: pkg install openssl-tool"
  exit 1
fi

read -p "Zadej doménu (např. google.com): " domain

echo
echo "Získávám certifikát z $domain ..."
echo

echo | openssl s_client -servername "$domain" -connect "$domain:443" 2>/dev/null \
  | openssl x509 -noout -issuer -subject -dates -fingerprint
