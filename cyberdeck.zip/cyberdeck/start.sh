#!/data/data/com.termux/files/usr/bin/bash
# CyberDeck – Hlavní menu s clear

while true; do
  clear  # vyčistí terminál při každém zobrazení menu

  echo "=== CyberDeck Control Center ==="
  echo
  echo "1) Menu and Help"
  echo "2) Security and Control"
  echo "3) Hacking"
  echo "4) Plugins"
  echo "5) Watch mode"
  echo
  echo "x) Exit"
  echo

  read -p "> " choice

  case "$choice" in
    1) bash ~/hacks/cyberdeck/mah.sh ;;
    2) bash ~/hacks/cyberdeck/sac.sh ;;
    3) bash ~/hacks/cyberdeck/h1.sh ;;
    4) bash ~/hacks/cyberdeck/plugins.sh ;;
    5) bash ~/hacks/cyberdeck/wm.sh ;;
    x|X)
      echo "Ukončuji CyberDeck. 👋"
      exit 0
      ;;
    *)
      echo "Neplatná volba."
      sleep 1
      ;;
  esac
done
